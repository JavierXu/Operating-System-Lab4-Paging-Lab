import sys
import math
import copy

# parse the input
command = sys.argv
command.pop(0)
command_int = []
for i in range(len(command)):
    if i != 5:
        command_int.append(int(command[i]))
    else:
        command_int.append(command[i])

# assign each input number with a specific meaning to conveniently use them
class Paging:
    def __init__(self, machine_size, page_size, process_size, job_mix, number_reference, replacement_algo, debug):
        self.machine_size = machine_size
        self.page_size = page_size
        self.process_size = process_size
        self.job_mix = job_mix
        self.number_reference = number_reference
        self.replacement_algo = replacement_algo
        self.debug = debug

    def get_ms(self):
        return self.machine_size

    def get_ps(self):
        return self.page_size

    def get_process_size(self):
        return self.process_size

    def get_jm(self):
        return self.job_mix

    def get_nr(self):
        return self.number_reference

    def get_ra(self):
        return self.replacement_algo

    def get_debug(self):
        return self.debug

# A, B, and C are probability 
# num_ref is the number of references per process 
# res is the total residency of the process
# eviction is the total number of times that the process is evicted
class Process:
    def __init__(self, A, B, C, num_ref):
        self.A = A
        self.B = B
        self.C = C
        self.num_ref = num_ref 
        self.reference_word = -1 
        self.faults = 0
        self.res = 0
        self.evictions = 0

    def getA(self):
        return self.A

    def getB(self):
        return self.B

    def getC(self):
        return self.C

    def get_num_ref(self):
        return self.num_ref

    def decrease_ref(self):
        self.num_ref -= 1

    def set_reference(self, ref):
        self.reference_word = ref

    def get_reference(self):
        return self.reference_word

    def increase_faults(self):
        self.faults += 1

    def get_faults(self):
        return self.faults

    def A_ref(self):
        self.reference_word += 1
        return self.reference_word

    def B_ref(self):
        self.reference_word -= 5
        return self.reference_word

    def C_ref(self):
        self.reference_word += 4
        return self.reference_word

    def increase_res(self, res):
        self.res += res

    def increase_eviction(self):
        self.evictions += 1

    def get_eviction(self):
        return self.evictions
    
    def get_res(self):
        return self.res

# pages in page frame table
# last_time used for lru algorithm: the last time the page was used
# loaded_time used for lifo algorithm: the time that the page was loaded
class Page:
    def __init__(self, page_number, process_number):
        self.page_number = page_number
        self.process_number = process_number
        self.loaded_time = 0
        self.last_time = 0 

    def get_page_num(self):
        return self.page_number

    def set_page_num(self, page_num):
        self.page_number = page_num

    def get_process_num(self):
        return self.process_number

    def set_process_num(self, process_num):
        self.process_number = process_num

    def set_loaded_time(self, time):
        self.loaded_time = time 

    def get_loaded_time(self):
        return self.loaded_time

    def set_last_time(self, time):
        self.last_time = time

    def get_last_time(self):
        return self.last_time

page = Paging(command_int[0], command_int[1], command_int[2], command_int[3], command_int[4], command_int[5], command_int[6])

print("The machine size is " + command[0])
print("The page size is "+command[1])
print("The process size is "+ command[2])
print("The job mix number is "+command[3])
print("The number of references per process is "+ command[4])
print("The replacement algorithm is "+command[5])
print("The level of debugging output is " + command[6])

# read the random number file
theFile = open("random-numbers.txt", "r")
theInts = []
for val in theFile.read().split(): # store random numbers in a list
    theInts.append(int(val))
theFile.close()

# create process list and put processes in it according to the job mix number
process_list = []
if page.get_jm() == 1:
    process_list.append(Process(1, 0, 0, page.get_nr()))

elif page.get_jm() == 2:
    for i in range(4):
        process_list.append(Process(1, 0, 0, page.get_nr()))

elif page.get_jm() == 3:
    for i in range(4):
        process_list.append(Process(0, 0, 0, page.get_nr()))

elif page.get_jm() == 4:
    process_list.append(Process(0.75, 0.25, 0, page.get_nr()))
    process_list.append(Process(0.75, 0, 0.25, page.get_nr()))
    process_list.append(Process(0.75, 0.125, 0.125, page.get_nr()))
    process_list.append(Process(0.5, 0.125, 0.125, page.get_nr()))

# create frame table
frame_table_size = int(page.get_ms()/page.get_ps())
frame_table = []
for i in range(frame_table_size):
    frame_table.append(Page(-1, -1))

#set initial reference word for each process
for proc in process_list:
    proc.set_reference(111*(process_list.index(proc)+1)%page.get_process_size())

#counting the total number of finished references
finished = 0
while finished < len(process_list)*page.get_nr():
    # go through each process
    for proc in process_list:
        # go through the quantum; 
        # if the references in the process is finished before the quantum, finished the process early
        i = 0
        while i < 3 and proc.get_num_ref() > 0:
            i += 1
            proc.decrease_ref()

            # page number to check and process number to check
            new_page = int(proc.get_reference()/page.get_ps())
            proc_num = process_list.index(proc)+1

            # set initial page frame table index to -1
            frame_index = -1
            cur = 0
            while cur < frame_table_size:
                if frame_table[cur].get_process_num() == proc_num and frame_table[cur].get_page_num() == new_page:
                    frame_index = cur
                    break
                cur += 1
            
            # hit in frame
            if frame_index >= 0:
                frame_table[frame_index].set_last_time(finished)
            
            # page faults, first find available page frame to use
            elif frame_index < 0:
                proc.increase_faults()
                cur1 = frame_table_size - 1
                while cur1 >= 0:
                    if frame_table[cur1].get_page_num() == -1:
                        frame_index = cur1
                        break
                    cur1 -= 1

                # available page frame found
                if frame_index >= 0:
                    pass

                # no available page frame, find page to evict
                elif frame_index < 0:

                    # least recently used algorithm: go through all pages in the page frame table 
                    # and find the page with the earliest accessed/used time to evict
                    if page.get_ra() == "lru":
                        last_time = -1
                        for cur2 in range(frame_table_size):
                            if frame_index < 0 or frame_table[cur2].get_last_time() < last_time:
                                frame_index = cur2
                                last_time = frame_table[cur2].get_last_time()

                    # last in first out algorithm: go through all pages in the page frame table 
                    # and find the page frame with the last loaded time to evict
                    elif page.get_ra() == "lifo":
                        loaded_time = -1
                        for cur2 in range(frame_table_size):
                            if frame_index < 0 or frame_table[cur2].get_loaded_time() > loaded_time:
                                frame_index = cur2
                                loaded_time = frame_table[cur2].get_loaded_time()

                    # random algorithm: find a random page frame to evict using the random number
                    elif page.get_ra() == "random":
                        r = theInts.pop(0)
                        frame_index = int(r % frame_table_size)

                    # evict the process in the evicted page
                    # increase the evicted process' residency and its number of evictions
                    frame = frame_table[frame_index]
                    evicted_proc = process_list[frame.get_process_num()-1]
                    evicted_proc.increase_res(finished - frame.get_loaded_time())
                    evicted_proc.increase_eviction()
                    
                # update the page with the new page number information and process number information
                # reset the page's last accessed time and last loaded time
                new_frame = frame_table[frame_index]
                new_frame.set_page_num(new_page)
                new_frame.set_process_num(proc_num)
                new_frame.set_loaded_time(finished)
                new_frame.set_last_time(finished)

            # find the next reference for the process
            r = theInts.pop(0)
            y = r/2147483648
            if y < proc.getA():
                proc.set_reference(proc.A_ref() % page.get_process_size())
            elif y < proc.getA() + proc.getB():
                proc.set_reference((proc.B_ref() + page.get_process_size())%page.get_process_size())
            elif y < proc.getA() + proc.getB() + proc.getC():
                proc.set_reference(proc.C_ref() % page.get_process_size())
            else:
                r = theInts.pop(0)
                proc.set_reference(r % page.get_process_size())
            finished += 1

total_evictions = 0
total_faults = 0
total_res = 0

# print out the output for each process
for proc in process_list:
    process_num = process_list.index(proc)+1

    # print out average residency if there is any eviction, otherwise undefined
    if proc.get_eviction() > 0:
        avg_res = proc.get_res()/proc.get_eviction()
        print("Process " + str(process_num) + " had " + str(proc.get_faults()) + " faults and " + str(avg_res) + " average residency")
    else:
        print("Process " + str(process_num) + " had " + str(proc.get_faults()) + " faults. \n     With no evictions, the average residency is undefined")

    #add up to get total page faults, evictions, and residency
    total_faults += proc.get_faults()
    total_res += proc.get_res()
    total_evictions += proc.get_eviction()
    
# print out the conclusion of all processes
if total_evictions != 0:
    print("The total number of faults is " + str(total_faults) + " and the overall average residency is " + str(total_res / total_evictions))
else:
    print("The total number of faults is " + str(total_faults) + " \n     With no evictions, the overall average residency is undefined")